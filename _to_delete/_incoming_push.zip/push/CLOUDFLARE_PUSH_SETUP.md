# Push notifications (Cloudflare Workers) — setup

This adds **Web Push** to the dashboard: when a risk **Alerta** appears (observed on *Agora* or
forecast on *Previsão*), everyone who tapped **"Receber alertas"** gets a notification on their
phone — even with the app closed. It runs entirely on **free** tiers (Cloudflare Workers + KV +
the browser push services). No server to maintain.

## How it works (30 seconds)

1. A visitor installs the app and taps **Receber alertas**. Their browser creates a private
   *subscription* and the site sends it to your Cloudflare **Worker**, which stores it in **KV**.
2. Once an hour the Worker wakes up (cron), fetches your published `data/snapshot.json` and
   `data/wrf_forecast.json`, and evaluates the **same thresholds** as the dashboard.
3. If a hazard reaches **Alerta** (and it's a new alert, not one already sent), the Worker sends an
   encrypted, signed push to every stored subscription. Dead subscriptions are pruned automatically.

The Worker code is in this folder: `worker.js` (+ `webpush.js`, `alerts.js`), configured by
`wrangler.toml`. The crypto and the alert logic are unit-tested (`npm test`).

---

## What you need

- A free **Cloudflare** account — <https://dash.cloudflare.com/sign-up>
- **Node.js** (which you already have) — used for one command and for Wrangler
- **Wrangler** (Cloudflare's CLI): `npm install -g wrangler`, then `wrangler login`

All commands below are run **inside this `push/` folder**.

---

## Step 1 — Generate your VAPID keys (once)

VAPID is the key pair that authorizes *you* (and only you) to push to your subscribers.

```bash
npx web-push generate-vapid-keys
```

It prints a **Public Key** and a **Private Key** (long base64url strings). Keep them handy.
The **private key is a secret** — it goes into Cloudflare, never into the site or Git.

## Step 2 — Create the KV namespace (once)

```bash
wrangler kv namespace create SUBSCRIPTIONS
```
*(older Wrangler: `wrangler kv:namespace create SUBSCRIPTIONS`)*

It prints an `id = "…"`. Open **`wrangler.toml`** and paste that id into `kv_namespaces[0].id`.

## Step 3 — Fill in `wrangler.toml`

In `[vars]` set:
- `VAPID_PUBLIC_KEY` = the **public** key from Step 1
- `VAPID_SUBJECT`    = `mailto:jessica.jcss@gmail.com` (already set)
- `SITE_BASE_URL`    = your live site, e.g. `https://jessicajcss.github.io/joinville_meteo/` (already set)
- `ALLOWED_ORIGIN`   = your site origin, `https://jessicajcss.github.io` (already set)

## Step 4 — Set the two secrets

```bash
wrangler secret put VAPID_PRIVATE_KEY      # paste the PRIVATE key from Step 1
wrangler secret put SEND_SECRET            # paste any long random string (your choice)
```

`SEND_SECRET` protects the manual `/test` endpoint. Keep it private.

## Step 5 — Deploy the Worker

```bash
wrangler deploy
```

Wrangler prints the Worker URL, like `https://joinville-push.<your-subdomain>.workers.dev`.
**Copy it.**

## Step 6 — Point the site at the Worker

Edit **`site/assets/js/push.js`** (top of the file) and set:
- `WORKER_URL` = the URL from Step 5
- `VAPID_PUBLIC_KEY` = the **public** key from Step 1 (same value as in `wrangler.toml`)

Commit and push the site as usual. Until these two values are set, the button politely shows
*"servidor a configurar"* and does nothing — so it's safe to ship the site before the Worker is ready.

## Step 7 — Subscribe and test

1. On your phone, open the live site and **install** it (iPhone: *Compartilhar → Adicionar à Tela de
   Início*; Android/desktop Chrome: the install prompt). **On iPhone push only works from the
   installed app** — this is Apple's rule.
2. Open the installed app, tap **Receber alertas**, allow notifications.
3. Fire a test from your computer:

```bash
curl -X POST "https://joinville-push.<your-subdomain>.workers.dev/test?key=YOUR_SEND_SECRET"
```

You should get a **"Joinville — teste"** notification. The response also reports how many devices it
reached (`{"sent":N,...}`).

That's it — from now on the hourly cron sends real alerts automatically.

---

## Tuning

- **Which level notifies.** By default only **Alerta** (severe) triggers a push. To also push
  **Atenção**, open `worker.js` and change `const NOTIFY_LEVEL = 'alert'` to `'warn'`, then
  `wrangler deploy`.
- **How often it checks.** `wrangler.toml` → `crons = ["0 * * * *"]` (hourly). The data updates daily
  (forecast) / weekly (observed), so hourly is plenty; you can slow it to e.g. `"0 */3 * * *"`.
- **Thresholds.** They mirror `site/previsao.html` and `build_site_data.py` (OMM rain, Beaufort wind,
  provisional temp bands, NWS heat index). If you change a threshold on the site, mirror it in
  `alerts.js` and redeploy.

## Cost & privacy

- **Free.** Cloudflare's free plan covers 100k Worker requests/day and generous KV usage — this uses a
  tiny fraction (one cron run/hour + a request per subscribe). The browser push services are free.
- **Privacy.** KV stores only anonymous push *subscriptions* (an opaque endpoint URL + encryption
  keys) — no names, no emails. Only your Worker, holding the secret VAPID key, can send to them.

## Troubleshooting

- **Button says "servidor a configurar"** → `WORKER_URL`/`VAPID_PUBLIC_KEY` in `push.js` still have
  placeholders (Step 6).
- **iPhone: nothing happens** → you must *install* the app first and open it from the Home Screen
  (Safari tab push is not supported by Apple).
- **`/test` returns `unauthorized`** → wrong `SEND_SECRET`.
- **`/test` returns `sent:0`** → no one is subscribed yet on that browser/device.
- **No alert ever fires** → conditions simply haven't reached **Alerta**; use `/test` to confirm
  delivery works, and check the Worker logs with `wrangler tail`.

## Verify the code locally (optional)

```bash
npm install      # dev-only deps: http_ece, web-push, jose
npm test         # crypto vs reference decryptor + VAPID + alert evaluators + Worker routes/cron
```
